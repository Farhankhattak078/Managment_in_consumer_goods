WITH cte3 AS (SELECT 
    p.segment,
    COUNT(DISTINCT CASE WHEN gp.fiscal_year = 2020 THEN gp.product_code END) AS unique_product_2020,
    COUNT(DISTINCT CASE WHEN gp.fiscal_year = 2021 THEN gp.product_code END) AS unique_product_2021
FROM dim_product p
JOIN fact_gross_price gp
    ON p.product_code = gp.product_code
GROUP BY p.segment)

SELECT *,

(unique_product_2021-unique_product_2020)

as difference
FROM cte3;