WITH cte8 AS (
    SELECT 
        p.product_code,
        p.division,
        p.product,
        SUM(s.sold_quantity) AS total_sold_quantity
    FROM dim_product p
    JOIN fact_sales_monthly s
        ON p.product_code = s.product_code
    WHERE s.fiscal_year = 2021
    GROUP BY p.product_code, p.division, p.product
),
ranked AS (
    SELECT 
        division,
        product_code,
        product,
        total_sold_quantity,
        ROW_NUMBER() OVER (PARTITION BY division ORDER BY total_sold_quantity DESC) AS rank_order
    FROM cte8
)
SELECT 
    division,
    product_code,
    product,
    total_sold_quantity,
    rank_order
FROM ranked
WHERE rank_order = 1
ORDER BY division;
