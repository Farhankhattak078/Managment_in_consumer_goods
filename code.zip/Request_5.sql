#Request 5
(SELECT p.product_code,p.product,mc.manufacturing_cost
FROM dim_product p 
JOIN fact_manufacturing_cost mc 
ON p.product_code=mc.product_code
ORDER BY manufacturing_cost ASC
LIMIT 1)
union all
(SELECT p.product_code,p.product,mc.manufacturing_cost
FROM dim_product p 
JOIN fact_manufacturing_cost mc 
ON p.product_code=mc.product_code
ORDER BY manufacturing_cost DESC
LIMIT 1);