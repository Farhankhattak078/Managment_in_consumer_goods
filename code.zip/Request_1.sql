#Request 1
select distinct(market) as market,region,customer
from dim_customer 
where region="APAC" and customer="Atliq Exclusive";