#Request 6
with cte4 as
(SELECT c.customer_code,c.customer,
sum(pid.pre_invoice_discount_pct)/count(pid.pre_invoice_discount_pct)*100 as averge_discount_percent
from dim_customer c
join fact_pre_invoice_deductions pid
on c.customer_code=pid.customer_code
where c.market='India' and pid.fiscal_year=2021
group by c.customer_code,c.customer)
select * from cte4
order by averge_discount_percent desc
limit 5;