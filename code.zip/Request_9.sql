#Request 9
WITH cte7 AS (
    SELECT 
        c.channel,
        Round((SUM(s.sold_quantity * gp.gross_price))/1000000,2) AS gross_sales_mln
    FROM dim_customer c
    JOIN fact_sales_monthly s 
        ON c.customer_code = s.customer_code
    JOIN fact_gross_price gp 
        ON s.product_code = gp.product_code
    WHERE gp.fiscal_year = 2021
    GROUP BY c.channel
)
SELECT 
    channel,
    gross_sales_mln,
    ROUND((gross_sales_mln * 100.0 / SUM(gross_sales_mln) over()), 2) AS percentage_contribution
FROM cte7
ORDER BY gross_sales_mln DESC;