#Request 8
with cte6 as (SELECT 
   date,concat('Q',quarter(date)) as Quarter
   ,sold_quantity
   from fact_sales_monthly
   where year(date)=2020
   order by sold_quantity desc)

select Quarter ,sum(sold_quantity)/1000000 as total_sold_quantity_mln
from cte6
group by Quarter
order by Quarter DESC;