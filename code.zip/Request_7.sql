#Request 7
with cte5 as
(SELECT month(s.date) as month,year(date) as year,
Round((s.sold_quantity*gp.gross_price),2) as gross_sale
from fact_sales_monthly s
join fact_gross_price gp
on s.product_code=gp.product_code
join dim_customer c
on c.customer_code=s.customer_code
where customer="Atliq Exclusive")

SELECT * FROM cte5
order by gross_sale desc;
